int main()
{
	int tab[] = {1,6,4,2,3,5};
	ft_sort_int_tab(tab,6);
	int k = 0;
	while (k < 6)
	{
		printf("%d ",tab[k]);
		k++;
	}
	return 0;
}

